from django.urls import path

from . import views

urlpatterns = [
    path("chat/", views.chat, name="ai-chat"),
    path("sessions/", views.session_for_factory, name="ai-sessions"),
    path("sessions/new/", views.start_new_session, name="ai-sessions-new"),
    path("sessions/history/", views.session_history, name="ai-sessions-history"),
    path("sessions/<uuid:session_id>/", views.session_detail, name="ai-session-detail"),
]
