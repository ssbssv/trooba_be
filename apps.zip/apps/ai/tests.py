"""
Tests for ChatSessionValidator (inactivity + model-version locks).
"""
from datetime import timedelta
from unittest.mock import MagicMock

from django.test import SimpleTestCase, override_settings
from django.utils import timezone

from apps.ai.models import ChatSession
from apps.ai.services.session_validator import (
    MODEL_CHANGED_MESSAGE,
    SESSION_TIMEOUT_MESSAGE,
    ChatSessionValidator,
    resolve_factory_model_version,
)


def _factory(**kwargs):
    factory = MagicMock()
    factory.id = kwargs.get("id", "factory-1")
    factory.updated_at = kwargs.get("updated_at", timezone.now())
    factory.last_run_at = kwargs.get("last_run_at", None)
    factory.run_status = kwargs.get("run_status", "current")
    return factory


def _session(**kwargs):
    session = MagicMock(spec=ChatSession)
    session.status = kwargs.get("status", ChatSession.STATUS_ACTIVE)
    session.lock_reason = kwargs.get("lock_reason", None)
    session.model_version = kwargs.get("model_version", "")
    session.last_activity_at = kwargs.get("last_activity_at", timezone.now())
    session.updated_at = kwargs.get("updated_at", timezone.now())
    session.created_at = kwargs.get("created_at", timezone.now())
    session.pk = kwargs.get("pk", "session-1")
    return session


class ChatSessionValidatorTests(SimpleTestCase):
    def setUp(self):
        self.validator = ChatSessionValidator()

    def test_active_session_passes(self):
        factory = _factory()
        session = _session(model_version=resolve_factory_model_version(factory))
        result = self.validator.validate(session, factory=factory)
        self.assertTrue(result.ok)
        self.assertFalse(result.session_expired)
        self.assertFalse(result.model_changed)

    @override_settings(CHAT_SESSION_INACTIVITY_TIMEOUT_SECONDS=3600)
    def test_inactivity_locks_session(self):
        factory = _factory()
        version = resolve_factory_model_version(factory)
        session = _session(
            model_version=version,
            last_activity_at=timezone.now() - timedelta(hours=2),
        )
        # Avoid real DB writes from lock_session.
        self.validator.lock_session = MagicMock(side_effect=lambda s, reason: setattr(s, "status", ChatSession.STATUS_READ_ONLY) or setattr(s, "lock_reason", reason) or s)

        result = self.validator.validate(session, factory=factory)
        self.assertFalse(result.ok)
        self.assertTrue(result.session_expired)
        self.assertEqual(result.message, SESSION_TIMEOUT_MESSAGE)
        self.validator.lock_session.assert_called_once()

    def test_model_change_locks_session(self):
        factory = _factory(updated_at=timezone.now())
        session = _session(model_version="stale-version")
        self.validator.lock_session = MagicMock(side_effect=lambda s, reason: setattr(s, "status", ChatSession.STATUS_READ_ONLY) or setattr(s, "lock_reason", reason) or s)

        result = self.validator.validate(session, factory=factory)
        self.assertFalse(result.ok)
        self.assertTrue(result.model_changed)
        self.assertEqual(result.message, MODEL_CHANGED_MESSAGE)

    def test_already_read_only_model_changed(self):
        factory = _factory()
        session = _session(
            status=ChatSession.STATUS_READ_ONLY,
            lock_reason=ChatSession.LOCK_MODEL_CHANGED,
        )
        result = self.validator.validate(session, factory=factory)
        self.assertFalse(result.ok)
        self.assertTrue(result.model_changed)

    @override_settings(CHAT_SESSION_EXPIRY_BEHAVIOR="auto_new")
    def test_auto_new_flag_on_timeout(self):
        factory = _factory()
        version = resolve_factory_model_version(factory)
        session = _session(
            model_version=version,
            last_activity_at=timezone.now() - timedelta(hours=2),
        )
        self.validator.lock_session = MagicMock(side_effect=lambda s, reason: setattr(s, "status", ChatSession.STATUS_READ_ONLY) or setattr(s, "lock_reason", reason) or s)
        result = self.validator.validate(session, factory=factory)
        self.assertTrue(result.should_auto_replace)
