from django.contrib import admin

from .models import ChatMessage, ChatSession


class ChatMessageInline(admin.TabularInline):
    model = ChatMessage
    extra = 0
    readonly_fields = ("id", "role", "message", "created_at")
    can_delete = False


@admin.register(ChatSession)
class ChatSessionAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "user",
        "factory",
        "scenario",
        "status",
        "lock_reason",
        "last_activity_at",
        "updated_at",
        "created_at",
    )
    list_filter = ("status", "lock_reason", "created_at", "updated_at")
    search_fields = ("id", "user__username", "user__email", "factory__name", "model_version")
    readonly_fields = ("id", "created_at", "updated_at", "last_activity_at", "model_version")
    inlines = [ChatMessageInline]


@admin.register(ChatMessage)
class ChatMessageAdmin(admin.ModelAdmin):
    list_display = ("id", "session", "role", "created_at")
    list_filter = ("role", "created_at")
    search_fields = ("message", "session__id")
    readonly_fields = ("id", "created_at")

