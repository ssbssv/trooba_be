"""
AIContextBuilder — loads complete factory input/output and conversation context.

Does NOT filter, summarize, or transform factory JSON.
"""
from __future__ import annotations

from typing import Any

from django.conf import settings

from apps.ai.models import ChatMessage, ChatSession
from apps.rmct.models import RMCMModel, Scenario, ScenarioResult


class AIContextBuilder:
    """Build the structured context payload sent to the LLM."""

    def __init__(self, *, max_recent_messages: int | None = None) -> None:
        self.max_recent_messages = (
            max_recent_messages
            if max_recent_messages is not None
            else int(getattr(settings, "MAX_RECENT_MESSAGES", 12))
        )

    def build(
        self,
        *,
        factory: RMCMModel,
        scenario: Scenario | None,
        session: ChatSession | None,
        current_question: str,
    ) -> dict[str, Any]:
        return {
            "factory_input": self.load_factory_input(factory),
            "factory_output": self.load_factory_output(factory, scenario),
            "scenario": self.load_scenario(scenario),
            "conversation_summary": (
                (session.conversation_summary or "") if session else ""
            ),
            "recent_messages": self.load_recent_messages(session),
            "current_question": current_question,
        }

    def load_factory_input(self, factory: RMCMModel) -> dict[str, Any]:
        """
        Load the COMPLETE factory input JSON exactly as stored.
        Do not remove, summarize, or transform fields.
        """
        from apps.rmct.views import _build_snapshot_from_model, _model_to_payload

        # Full nested factory data (includes dept_codes) plus model metadata.
        snapshot = _build_snapshot_from_model(factory)
        meta = _model_to_payload(factory)
        return {
            **meta,
            **snapshot,
        }

    def load_factory_output(
        self,
        factory: RMCMModel,
        scenario: Scenario | None,
    ) -> dict[str, Any] | list[Any] | None:
        """
        Load the COMPLETE calculated output JSON for the current scenario
        (or basecase when no scenario is selected).
        """
        target = scenario
        if target is None:
            target = Scenario.objects.filter(model=factory, is_basecase=True).first()
        if target is None:
            return None
        try:
            result = target.result
        except ScenarioResult.DoesNotExist:
            return None
        return result.results

    def load_scenario(self, scenario: Scenario | None) -> dict[str, Any]:
        if scenario is None:
            return {
                "id": None,
                "name": None,
                "is_current": True,
                "is_basecase": True,
                "description": "Basecase (current factory model)",
                "status": None,
            }
        return {
            "id": str(scenario.id),
            "name": scenario.name,
            "is_current": True,
            "is_basecase": bool(scenario.is_basecase),
            "description": scenario.description or "",
            "status": scenario.status or "",
        }

    def load_recent_messages(
        self,
        session: ChatSession | None,
    ) -> list[dict[str, Any]]:
        if session is None:
            return []
        qs = ChatMessage.objects.filter(session=session).order_by("-created_at")[
            : self.max_recent_messages
        ]
        rows = list(reversed(list(qs)))
        return [
            {
                "role": row.role,
                "message": row.message,
                "created_at": row.created_at.isoformat() if row.created_at else None,
            }
            for row in rows
        ]
