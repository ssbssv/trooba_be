"""
ChatSessionValidator — inactivity timeout and factory model-version locks.

Keep this out of Django views. ChatService calls validate() before any LLM work.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import timedelta

from django.conf import settings
from django.utils import timezone

from apps.ai.models import ChatSession
from apps.rmct.models import RMCMModel

SESSION_TIMEOUT_MESSAGE = (
    "This conversation has been inactive for more than 1 hour. "
    "Please start a new conversation."
)
MODEL_CHANGED_MESSAGE = (
    "The factory model has changed since this conversation started. "
    "Please create a new conversation to discuss the latest factory results."
)

# Option A: return session_expired and require the client to start a new chat.
EXPIRY_BEHAVIOR_PROMPT_NEW = "prompt_new"
# Option B: automatically create a new ChatSession and continue.
EXPIRY_BEHAVIOR_AUTO_NEW = "auto_new"


def resolve_factory_model_version(factory: RMCMModel) -> str:
    """
    Fingerprint of the factory's current analysis state.

    Bumps when the model is edited or recalculated so chats pin to the results
    that were current when the conversation started.
    """
    updated = factory.updated_at.isoformat() if factory.updated_at else ""
    last_run = factory.last_run_at.isoformat() if factory.last_run_at else ""
    run_status = factory.run_status or ""
    return f"{factory.id}:{updated}:{last_run}:{run_status}"


def inactivity_timeout() -> timedelta:
    seconds = int(getattr(settings, "CHAT_SESSION_INACTIVITY_TIMEOUT_SECONDS", 3600))
    return timedelta(seconds=max(1, seconds))


def expiry_behavior() -> str:
    raw = (
        getattr(settings, "CHAT_SESSION_EXPIRY_BEHAVIOR", EXPIRY_BEHAVIOR_PROMPT_NEW)
        or EXPIRY_BEHAVIOR_PROMPT_NEW
    )
    value = str(raw).strip().lower()
    if value in ("auto_new", "auto", "b", "option_b"):
        return EXPIRY_BEHAVIOR_AUTO_NEW
    return EXPIRY_BEHAVIOR_PROMPT_NEW


@dataclass
class SessionValidationResult:
    """Outcome of validating a chat session before an LLM turn."""

    ok: bool
    session: ChatSession
    session_expired: bool = False
    model_changed: bool = False
    message: str = ""
    # When Option B auto-creates a replacement session, this is set.
    replacement_session: ChatSession | None = None

    @property
    def should_auto_replace(self) -> bool:
        return (
            self.session_expired
            and not self.ok
            and expiry_behavior() == EXPIRY_BEHAVIOR_AUTO_NEW
        )


class ChatSessionValidator:
    """
    Validate inactivity timeout and model version.
    Lock expired / outdated chats as READ_ONLY.
    """

    def validate(
        self,
        session: ChatSession,
        *,
        factory: RMCMModel,
    ) -> SessionValidationResult:
        if session.status == ChatSession.STATUS_READ_ONLY:
            return self._result_for_locked(session)

        model_result = self._check_model_version(session, factory)
        if not model_result.ok:
            return model_result

        return self._check_inactivity(session)

    def lock_session(
        self,
        session: ChatSession,
        *,
        reason: str,
    ) -> ChatSession:
        if (
            session.status == ChatSession.STATUS_READ_ONLY
            and session.lock_reason == reason
        ):
            return session

        session.status = ChatSession.STATUS_READ_ONLY
        session.lock_reason = reason
        session.save(update_fields=["status", "lock_reason", "updated_at"])
        return session

    def touch_activity(self, session: ChatSession) -> None:
        now = timezone.now()
        ChatSession.objects.filter(pk=session.pk).update(
            last_activity_at=now,
            updated_at=now,
        )
        session.last_activity_at = now
        session.updated_at = now

    def _check_model_version(
        self,
        session: ChatSession,
        factory: RMCMModel,
    ) -> SessionValidationResult:
        current = resolve_factory_model_version(factory)
        stored = (session.model_version or "").strip()
        if not stored:
            # Legacy / missing fingerprint: pin to current without locking.
            session.model_version = current
            session.save(update_fields=["model_version", "updated_at"])
            return SessionValidationResult(ok=True, session=session)

        if stored == current:
            return SessionValidationResult(ok=True, session=session)

        self.lock_session(session, reason=ChatSession.LOCK_MODEL_CHANGED)
        return SessionValidationResult(
            ok=False,
            session=session,
            model_changed=True,
            message=MODEL_CHANGED_MESSAGE,
        )

    def _check_inactivity(self, session: ChatSession) -> SessionValidationResult:
        last = session.last_activity_at or session.updated_at or session.created_at
        if last is None:
            return SessionValidationResult(ok=True, session=session)

        idle = timezone.now() - last
        if idle <= inactivity_timeout():
            return SessionValidationResult(ok=True, session=session)

        self.lock_session(session, reason=ChatSession.LOCK_SESSION_TIMEOUT)
        return SessionValidationResult(
            ok=False,
            session=session,
            session_expired=True,
            message=SESSION_TIMEOUT_MESSAGE,
        )

    def _result_for_locked(self, session: ChatSession) -> SessionValidationResult:
        if session.lock_reason == ChatSession.LOCK_MODEL_CHANGED:
            return SessionValidationResult(
                ok=False,
                session=session,
                model_changed=True,
                message=MODEL_CHANGED_MESSAGE,
            )
        return SessionValidationResult(
            ok=False,
            session=session,
            session_expired=True,
            message=SESSION_TIMEOUT_MESSAGE,
        )
