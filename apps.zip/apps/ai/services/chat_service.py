"""
ChatService — orchestrates context building, LLM calls, and conversation storage.

No tool calling in Version 1. Architecture leaves room for Version 2 tools
without changing this service's public contract.

Session lifecycle (inactivity / model version) is validated via ChatSessionValidator
before any LLM request. AI logic itself is unchanged.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from uuid import UUID

from django.contrib.auth.models import AbstractBaseUser
from django.utils import timezone

from apps.ai.llm.base import LLMClient, LLMMessage
from apps.ai.llm.http import LLMProviderError
from apps.ai.models import ChatMessage, ChatSession
from apps.ai.prompts import SYSTEM_PROMPT
from apps.ai.services.context_builder import AIContextBuilder
from apps.ai.services.conversation_memory import ConversationMemoryService
from apps.ai.services.session_validator import (
    ChatSessionValidator,
    SessionValidationResult,
    resolve_factory_model_version,
)
from apps.rmct.models import RMCMModel, Scenario


class ChatSessionLockedError(Exception):
    """Raised when a chat cannot accept new messages (timeout or model change)."""

    def __init__(self, result: SessionValidationResult) -> None:
        super().__init__(result.message or "Chat session is read-only")
        self.result = result


@dataclass
class ChatTurnResult:
    session: ChatSession
    user_message: ChatMessage
    assistant_message: ChatMessage


class ChatService:
    """
    Application service for Trooba Flow AI chat.

    Dependencies are injected so providers and builders can be swapped in tests
    or future versions (e.g. tool-calling LLMClient).
    """

    def __init__(
        self,
        *,
        llm_client: LLMClient,
        context_builder: AIContextBuilder | None = None,
        memory: ConversationMemoryService | None = None,
        session_validator: ChatSessionValidator | None = None,
    ) -> None:
        self.llm_client = llm_client
        self.context_builder = context_builder or AIContextBuilder()
        self.memory = memory or ConversationMemoryService(llm_client)
        self.session_validator = session_validator or ChatSessionValidator()

    def create_session(
        self,
        *,
        user: AbstractBaseUser,
        factory: RMCMModel,
        scenario: Scenario | None,
    ) -> ChatSession:
        """Start a fresh ACTIVE chat for the workspace context."""
        now = timezone.now()
        return ChatSession.objects.create(
            user=user,
            factory=factory,
            scenario=scenario,
            conversation_summary="",
            status=ChatSession.STATUS_ACTIVE,
            lock_reason=None,
            model_version=resolve_factory_model_version(factory),
            last_activity_at=now,
        )

    def get_or_create_session(
        self,
        *,
        user: AbstractBaseUser,
        factory: RMCMModel,
        scenario: Scenario | None,
        session_id: UUID | str | None = None,
        force_new: bool = False,
    ) -> ChatSession:
        if force_new:
            return self.create_session(user=user, factory=factory, scenario=scenario)

        if session_id:
            session = ChatSession.objects.filter(
                id=session_id,
                user=user,
                factory=factory,
            ).first()
            if session is not None:
                # Keep scenario aligned with the active workspace selection.
                if session.scenario_id != (scenario.id if scenario else None):
                    session.scenario = scenario
                    session.save(update_fields=["scenario", "updated_at"])
                return session

        # Prefer the most recent ACTIVE session for this user/factory/scenario.
        qs = ChatSession.objects.filter(user=user, factory=factory)
        if scenario is None:
            qs = qs.filter(scenario__isnull=True)
        else:
            qs = qs.filter(scenario=scenario)

        existing = qs.filter(status=ChatSession.STATUS_ACTIVE).order_by(
            "-last_activity_at", "-updated_at"
        ).first()
        if existing:
            return existing

        # Fall back to latest session (may be READ_ONLY) so callers can load history;
        # ask() will validate and lock/reject as needed.
        latest = qs.order_by("-updated_at").first()
        if latest:
            return latest

        return self.create_session(user=user, factory=factory, scenario=scenario)

    def ask(
        self,
        *,
        user: AbstractBaseUser,
        factory: RMCMModel,
        scenario: Scenario | None,
        question: str,
        session_id: UUID | str | None = None,
        force_new: bool = False,
    ) -> ChatTurnResult:
        question = (question or "").strip()
        if not question:
            raise ValueError("message is required")

        session = self.get_or_create_session(
            user=user,
            factory=factory,
            scenario=scenario,
            session_id=session_id,
            force_new=force_new,
        )

        validation = self.session_validator.validate(session, factory=factory)
        if not validation.ok:
            if validation.should_auto_replace:
                # Option B: inactivity only — start a new session and continue.
                session = self.create_session(
                    user=user,
                    factory=factory,
                    scenario=scenario,
                )
            else:
                raise ChatSessionLockedError(validation)

        # Build context before persisting the new user turn so recent_messages
        # contains prior history only; current_question is sent separately.
        context = self.context_builder.build(
            factory=factory,
            scenario=scenario,
            session=session,
            current_question=question,
        )
        messages = self._build_llm_messages(context)

        user_row = self.memory.save_user_message(session, question)

        try:
            response = self.llm_client.chat(messages)
            assistant_text = (response.content or "").strip()
            if not assistant_text:
                assistant_text = "ai is out of service pls try again later"
        except LLMProviderError:
            assistant_text = "ai is out of service pls try again later"

        assistant_row = self.memory.save_assistant_message(session, assistant_text)

        # Summarize after the turn is persisted so thresholds see the new messages.
        try:
            self.memory.maybe_summarize(session)
        except LLMProviderError:
            # Summarization failure must not break the user-facing reply.
            pass

        session.refresh_from_db()
        return ChatTurnResult(
            session=session,
            user_message=user_row,
            assistant_message=assistant_row,
        )

    def list_messages(self, session: ChatSession) -> list[ChatMessage]:
        return list(session.messages.order_by("created_at"))

    @staticmethod
    def _build_llm_messages(context: dict[str, Any]) -> list[LLMMessage]:
        """
        Build provider-agnostic messages with structured JSON user content.

        messages = [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: { factory_input, factory_output, ... } },
        ]
        """
        return [
            LLMMessage(role="system", content=SYSTEM_PROMPT),
            LLMMessage(
                role="user",
                content={
                    "factory_input": context["factory_input"],
                    "factory_output": context["factory_output"],
                    "scenario": context["scenario"],
                    "conversation_summary": context["conversation_summary"],
                    "recent_messages": context["recent_messages"],
                    "current_question": context["current_question"],
                },
            ),
        ]

